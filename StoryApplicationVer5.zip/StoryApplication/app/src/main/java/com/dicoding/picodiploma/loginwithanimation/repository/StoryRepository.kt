package com.dicoding.picodiploma.loginwithanimation.repository

import android.util.Log
import com.dicoding.picodiploma.loginwithanimation.data.api.ApiService
import com.dicoding.picodiploma.loginwithanimation.data.model.Story
import com.dicoding.picodiploma.loginwithanimation.data.pref.UserPreference
import kotlinx.coroutines.flow.first
import retrofit2.HttpException
import java.io.IOException

class StoryRepository private constructor(
    private val apiService: ApiService,
    private val userPreference: UserPreference
) {

    suspend fun getStories(): List<Story> {
        val token = userPreference.getToken().first() ?: ""
        Log.d("StoryRepository", "Fetching stories with token: $token")
        return try {
            val response = apiService.getStories()
            if (response.isSuccessful) {
                response.body()?.stories?.map {
                    Story(
                        id = it.id ?: "",
                        name = it.name ?: "",
                        description = it.description ?: "",
                        photoUrl = it.photoUrl ?: "",
                        createdAt = it.createdAt ?: "",
                        lat = it.lat ?: 0.0,
                        lon = it.lon ?: 0.0
                    )
                } ?: emptyList()
            } else {
                Log.e("StoryRepository", "Failed to fetch stories: ${response.message()}")
                emptyList()
            }
        } catch (e: IOException) {
            Log.e("StoryRepository", "Network error: ${e.message}")
            emptyList()
        } catch (e: HttpException) {
            Log.e("StoryRepository", "HTTP error: ${e.message()}")
            emptyList()
        }
    }

    companion object {
        @Volatile
        private var instance: StoryRepository? = null

        fun getInstance(apiService: ApiService, userPreference: UserPreference): StoryRepository =
            instance ?: synchronized(this) {
                instance ?: StoryRepository(apiService, userPreference).also { instance = it }
            }
    }
}
