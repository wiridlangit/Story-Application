package com.dicoding.picodiploma.loginwithanimation.view.story

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.loginwithanimation.R
import com.dicoding.picodiploma.loginwithanimation.data.model.Story

class StoryAdapter(private val stories: List<Story>) : RecyclerView.Adapter<StoryAdapter.StoryViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_story, parent, false)
        return StoryViewHolder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: StoryViewHolder, position: Int) {
        val story = stories[position]
        holder.storyTitle.text = story.name
        holder.storyDescription.text = story.description.substring(0, minOf(story.description.length, 100)) + "..."

        Glide.with(holder.itemView.context)
            .load(story.photoUrl)
            .into(holder.storyImage)

        holder.cardView.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailStoryActivity::class.java)
            intent.putExtra("story", story)

            val optionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(
                holder.itemView.context as Activity,
                androidx.core.util.Pair(holder.storyImage, "image"),
                androidx.core.util.Pair(holder.storyTitle, "title"),
                androidx.core.util.Pair(holder.storyDescription, "description")
            )

            holder.itemView.context.startActivity(intent, optionsCompat.toBundle())
        }
    }

    override fun getItemCount(): Int = stories.size

    class StoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardView: CardView = view.findViewById(R.id.cardView)
        val storyTitle: TextView = view.findViewById(R.id.storyTitle)
        val storyDescription: TextView = view.findViewById(R.id.storyDescription)
        val storyImage: ImageView = view.findViewById(R.id.storyImage)
    }
}
