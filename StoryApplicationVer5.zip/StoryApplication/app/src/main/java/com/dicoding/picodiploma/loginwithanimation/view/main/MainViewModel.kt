package com.dicoding.picodiploma.loginwithanimation.view.main

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.dicoding.picodiploma.loginwithanimation.data.model.Story
import com.dicoding.picodiploma.loginwithanimation.data.pref.UserModel
import com.dicoding.picodiploma.loginwithanimation.repository.UserRepository
import com.dicoding.picodiploma.loginwithanimation.repository.StoryRepository
import kotlinx.coroutines.launch

class MainViewModel(
    private val userRepository: UserRepository,
    private val storyRepository: StoryRepository?
) : ViewModel() {

    private val _storiesLiveData = MutableLiveData<List<Story>>()
    val storiesLiveData: LiveData<List<Story>> get() = _storiesLiveData

    init {
        loadStories()
    }

    private fun loadStories() {
        viewModelScope.launch {
            try {
                storyRepository?.let {
                    val stories = it.getStories()
                    _storiesLiveData.postValue(stories)
                    Log.d("MainViewModel", "Stories loaded successfully")
                } ?: run {
                    Log.d("MainViewModel", "StoryRepository is null")
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error loading stories", e)
            }
        }
    }

    fun getSession(): LiveData<UserModel> {
        return userRepository.getSession().asLiveData()
    }

    fun logout(token: String) {
        viewModelScope.launch {
            userRepository.logout(token)
        }
    }
}
